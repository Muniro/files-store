using System;
using System.Data;
using Xunit;

namespace Utilities.Tests
{
    public class SumCalculatorTests
    {

        private ISumOperator addCalculator;

        public SumCalculatorTests()
        {
            addCalculator = new SumCalculator();
        }
        [Fact]
        public void AddStringNumbers_GivenEmptyString_ShouldReturnZero()
        {
           
            string numbers = ""; 

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(0, sut);

        }

        [Fact]
        public void AddStringNumbers_GivenOneStringNumber_ShouldReturnNumber()
        {

            string numbers = "1";

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(int.Parse(numbers), sut);


        }


        [Fact]
        public void AddStringNumbers_GivenTwoStringNumbers_ShouldReturnSum()
        {

            string numbers = "1,2";
            int expectedNumber = 3;

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expectedNumber, sut);

        }


        [Fact]
        public void AddStringNumbers_GivenAnyStringNumbers_ShouldReturnSum()
        {

            string numbers = "1,2,3,4,5,7";
            int expectedNumber = 22;

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expectedNumber, sut);

        }


        [Fact]
        public void AddStringNumbers_GivenStringNumbersWithNewLineInBetweenNumbers_ShouldReturnSum()
        {

            string numbers = "1\n2,3";
            int expectedNumber = 6;

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expectedNumber, sut);

        }


        [Fact]
        public void AddStringNumbers_GivenNewLineInsteadOfStringNumbers_ShouldReturnZero()
        {

            string numbers = "1,\n,2,3";
            int expectedNumber = 0;

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expectedNumber, sut);

        }

        [Fact]
        public void AddStringNumbers_GivenAnyDelimiterAndStringNumbers_ShouldReturnSum()
        {

            string numbers = "//;\n1;2";
            int expectedNumber = 3;

            var sut = addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expectedNumber, sut);

        }
        [Fact]
        public void AddStringNumbers_GivenNegativedStringNumber_ShouldThrowAnException()
        {

            string numbers = "//;\n1;-2; -3";
            Assert.Throws<Exception>(() => addCalculator.AddStringNumbers(numbers));
        }

        [Fact]
        public void AddStringNumbers_GivenNumberBiggerThanMaxStringNumber_ShouldNotAddThatMaxNumber()
        {
            int expected = 6;
            string numbers = "2,3,1001,1";
           var sut=addCalculator.AddStringNumbers(numbers);

            Assert.Equal(expected, sut);
        }

        
    }
}

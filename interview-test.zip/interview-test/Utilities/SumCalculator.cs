﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using Utilities.Helper;

namespace Utilities
{
    public class SumCalculator : ISumOperator
    {
        private const string newlineString = "\n";
        private const int lengthOfNewlineString = 2;
        private string defaultDelimiterString = ","; //default delimiter
        private string delimiterString =  "," ; 
        private const string delimiterStartingChar = "//";
        private const int highestNumberAllowed = 1000;
        public int AddStringNumbers(string delimiterSeparatedNumbers)
        {
            //note we could do If statements in one line, 
            //but good guidelines favours readability over conciseness

            //Point 1,  empty strings
            if (delimiterSeparatedNumbers.Length == 0)
            {
                return 0;
            }
            //Point 3, b: "1,\n" not allowed
            if (delimiterSeparatedNumbers.Split(',').Contains(newlineString))
            {
                return 0; //not alloweds
            }
            //Point 4, allows unlimited delimiters, starting with // and ending with \n
            if (delimiterSeparatedNumbers.StartsWith(delimiterStartingChar))
            {
                //extract the delimiter!
                delimiterString = delimiterSeparatedNumbers.Substring(delimiterSeparatedNumbers.LastIndexOf(delimiterStartingChar) + delimiterStartingChar.Length, delimiterSeparatedNumbers.IndexOf(newlineString) - lengthOfNewlineString);
                //check whether there are more than the default delimiter being passed in
                //we need to clean out the string numbers so it works for the rest of the code
                delimiterSeparatedNumbers = delimiterSeparatedNumbers.Remove(0, delimiterStartingChar.Length);

            }
            //Point 3, a: "1\n2,3" is allowed
            if (delimiterSeparatedNumbers.Contains(newlineString))
            {
                delimiterSeparatedNumbers = delimiterSeparatedNumbers.Replace(newlineString, delimiterString);
            }
            IList<string> numbers = GeneralHelper.ExtractNumbers(delimiterSeparatedNumbers,delimiterString);
            //Point 5: negative numbers not allowed, this could be refactored but for now passes the test
            var negativeNumbers = numbers.ToList().FindAll(x => x.Trim().StartsWith("-"));

            if (negativeNumbers.Count > 0)
            {
                string negativeListToDisplay = String.Empty;
                negativeNumbers.ForEach(x =>
                {
                    negativeListToDisplay += String.Concat(x, " ");
                });
                throw new Exception($"Negative numbers {negativeListToDisplay}not allowed");
            }

            //Point 6: check of any numbers greater than maximum value allowed
            numbers = numbers.Where(x => int.Parse(x) <= highestNumberAllowed).ToList();

            int sum = numbers.Select(x => int.Parse(x)).Sum();

            return sum;


        }

    }
}

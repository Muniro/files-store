﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities
{
   public interface ISumOperator
    {
        int AddStringNumbers(string commaSeparatedNumbers);

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.Helper
{
    public static class GeneralHelper
    {
        internal static IList<string> ExtractNumbers(string delimiterSeparatedNumbers, string delimiterString)
        {
            return delimiterSeparatedNumbers.Split(new string[] { delimiterString }, StringSplitOptions.RemoveEmptyEntries);
        }

    }
}
